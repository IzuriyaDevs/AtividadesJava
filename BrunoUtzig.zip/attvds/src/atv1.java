import java.util.Scanner;
public class atv1 {

	public static void main(String[] args) {
		
Scanner sc= new Scanner(System.in);
int x= sc.nextInt();
String dia;
 System.out.println("Qual o seu c�digo de funcion�rio");
 int code = sc.nextInt();
 
 System.out.println("Qual o seu sal�rio");
 float salario = sc.nextFloat();
 showInfo(code,salario);
}
 public static void showInfo(int code,float salario) {
	 double percentual = 1;
	 switch(code) {
	 case 1:
		 System.out.println("C�digo1-Escritu�rio");
		 percentual=1.5;
		 break;
		 
	 case 2:
		 System.out.println("C�digo2-Scret�rio");
		 percentual=1.35;
		 break;
		 
	 case 3:
		 System.out.println("C�digo3-Caixa");
		 percentual=1.20;
		 break;
		 
	 case 4:
		 System.out.println("C�digo4-Gerente");
		 percentual=1.10;
		 break;
		 
	 case 5:
		 System.out.println("C�digo5-Diretor");
		 break;
		 default: 
			 System.out.println("Valor inv�lido!!!");
			 main(null);
			 break;
			 
	 }
	 System.out.println("Aumento de sal�rio: "+(salario*percentual));
 }	
	
}
