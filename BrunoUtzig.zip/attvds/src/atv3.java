import java.util.Scanner;
public class atv3 {

	public static void main(String[] args) {
		
Scanner sc= new Scanner(System.in);

 System.out.println("Quantidade de livros");
 int livros =sc.nextInt();
 showInfo(livros);
}
 public static void showInfo(int livros) {
	 double A=0.25*livros+7.5;
	 double B=0.5*livros+2.5;
	 
	 boolean bBigger=(B>A);
	 
	 if(bBigger)
		 System.out.println("A melhor op��o");
	 
	 else
		 System.out.println("B melhor op��o");
	 }
 }
		
 
