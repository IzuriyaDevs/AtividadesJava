import java.util.Scanner;
public class atv4 {

	public static void main(String[] args) {
		
Scanner sc= new Scanner(System.in);

 System.out.println("qual o valor da compra");
 float v_total =sc.nextFloat();
 System.out.println("qual a Forma de pagamento");
 System.out.println("1-� vista");
 System.out.println("2-cheque pr� datado");
 System.out.println("3-parcelado em 6x");
 System.out.println("4-parcelado em 12x");
 int FormaPg =sc.nextInt();
 showInfo(v_total,FormaPg);
}
 public static void showInfo(float v_total, int FormaPg) {	 
double percentual = 1;
 switch(FormaPg) {
 case 1:
	 
	 percentual=0.85;
	 break;
	 
 case 2:
	
	 percentual=0.9;
	 break;
	 
 case 3:
	 
	
	 break;
	 
 case 4:
	 
	 percentual=1.08;
	 break;
	 
	 default: 
		 System.out.println("Valor inv�lido!!!");
		 main(null);
		 break;
		 
 }
 System.out.println("Vlor total"+(v_total));
 System.out.println("Vlor total"+(v_total*percentual));
 
 double diferen�a = (1-percentual)*v_total;
 if (diferen�a<0)
 System.out.println("Diferen�a: "+(-diferen�a)+" juros");
 else 
	 System.out.println("Diferen�a: "+diferen�a+" juros");
	 }
 }
		
 
